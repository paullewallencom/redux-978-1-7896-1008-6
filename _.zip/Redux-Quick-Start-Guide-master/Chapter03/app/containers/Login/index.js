import React, { PureComponent } from 'react';

/* eslint-disable react/prefer-stateless-function */
export default class Login extends PureComponent {
  render() {
    return <h1>This is the Login</h1>;
  }
}

import React from "react";

/* eslint-disable react/prefer-stateless-function */
export default class NotFound extends React.PureComponent {
  render() {
    return <h1>This is the NotFoundPage container!</h1>;
  }
}

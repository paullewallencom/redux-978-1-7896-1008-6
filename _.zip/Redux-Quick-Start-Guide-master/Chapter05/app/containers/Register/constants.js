export const REGISTER_REQUEST = 'raskLege/Register/REGISTER_REQUEST';
export const REGISTER_SUCCESS = 'raskLege/Register/REGISTER_SUCCESS';
export const REGISTER_FAILURE = 'raskLege/Register/REGISTER_FAILURE';

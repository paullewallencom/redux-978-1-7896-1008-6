export const LOGIN_REQUEST = 'raskLege/Login/LOGIN_REQUEST';
export const LOGIN_SUCCESS = 'raskLege/Login/LOGIN_SUCCESS';
export const LOGIN_FAILURE = 'raskLege/Login/LOGIN_FAILURE';
export const LOGOUT_REQUEST = 'raskLege/Login/LOGOUT_REQUEST';
export const LOGOUT_SUCCESS = 'raskLege/Login/LOGOUT_SUCCESS';
export const LOGOUT_FAILURE = 'raskLege/Login/LOGOUT_FAILURE';

export const USER_SEARCH_REQUEST = 'raskLege/User/USER_SEARCH_REQUEST';
export const USER_SEARCH_SUCCESS = 'raskLege/User/USER_SEARCH_SUCCESS';
export const USER_SEARCH_FAILURE = 'raskLege/User/USER_SEARCH_FAILURE';

export const USER_REMOVE_REQUEST = 'raskLege/User/USER_REMOVE_REQUEST';
export const USER_REMOVE_SUCCESS = 'raskLege/User/USER_REMOVE_SUCCESS';
export const USER_REMOVE_FAILURE = 'raskLege/User/USER_REMOVE_FAILURE';

export const USER_UPDATE_REQUEST = 'raskLege/User/USER_UPDATE_REQUEST';
export const USER_UPDATE_SUCCESS = 'raskLege/User/USER_UPDATE_SUCCESS';
export const USER_UPDATE_FAILURE = 'raskLege/User/USER_UPDATE_FAILURE';

export const USER_CREATE_REQUEST = 'raskLege/User/USER_CREATE_REQUEST';
export const USER_CREATE_SUCCESS = 'raskLege/User/USER_CREATE_SUCCESS';
export const USER_CREATE_FAILURE = 'raskLege/User/USER_CREATE_FAILURE';

export const USER_DETAIL_REQUEST = 'raskLege/User/USER_DETAIL_REQUEST';
export const USER_DETAIL_SUCCESS = 'raskLege/User/USER_DETAIL_SUCCESS';
export const USER_DETAIL_FAILURE = 'raskLege/User/USER_DETAIL_FAILURE';

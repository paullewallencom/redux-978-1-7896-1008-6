import React from "react";

const Alerts = () => (
  <ul>
    <li>This is notification one.</li>
    <li>This is notification two.</li>
  </ul>
);

export default Alerts;

export const ADD_NEW_DOCTOR = "ADD_NEW_DOCTOR";

export function addNewDoctor(newDoctorData) {
  return {
    type: "ADD_NEW_DOCTOR",
    newDoctorData
  };
}

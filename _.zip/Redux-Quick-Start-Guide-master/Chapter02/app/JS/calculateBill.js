const calculateBill = (totalHours, ratePerHours) => totalHours * ratePerHours;

module.exports = calculateBill;

import React from "react";
import Link from "react-router-dom/Link";

const Logo = () => (
  <div>
    <Link to="/">FastDoctor</Link>
  </div>
);

export default Logo;

import { IS_USER_AUTHENTICATED } from './constants';

export const onApplicationLoad = () => ({ type: IS_USER_AUTHENTICATED });

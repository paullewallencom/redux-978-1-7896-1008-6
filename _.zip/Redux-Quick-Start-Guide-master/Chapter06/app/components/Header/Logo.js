import React from 'react';
import LogoImg from './logo.png';

export default props => (
  <img alt="" className="logo-header" src={LogoImg} {...props} />
);

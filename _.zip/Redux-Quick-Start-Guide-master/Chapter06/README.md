# Rask Lege

## DB Schema

https://www.lucidchart.com/invitations/accept/f7325a1b-cff5-4d30-946a-79984348537c

<img width="837" alt="screenshot 2018-11-26 at 11 21 27" src="https://user-images.githubusercontent.com/2022919/49008207-8df25b80-f16d-11e8-9998-c8c483b001e3.png">

# Getting Started

## Install dependencies

```
yarn install
```

## Start the web

```
yarn start
```

The web admin should be available at http://localhost:3000/

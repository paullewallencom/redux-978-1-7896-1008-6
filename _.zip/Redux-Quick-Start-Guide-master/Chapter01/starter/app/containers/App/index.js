import React from 'react';

import HomePage from 'containers/HomePage/Loadable';

export default function App() {
  return (
    <div>
      <HomePage />
    </div>
  );
}
